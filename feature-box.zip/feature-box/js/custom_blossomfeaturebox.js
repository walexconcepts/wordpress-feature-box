
jQuery(document).ready(function($) {


blossomfeaturebox.init({
		optinfile: php_vars.var1,
		fxeffect: php_vars.var2, 
		displaytype: php_vars.var3, 
		displayfreq: {duration: php_vars.var4, cookiename: 'featurebox'} 
	})

});
